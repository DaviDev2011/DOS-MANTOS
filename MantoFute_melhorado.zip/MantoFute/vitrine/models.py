from django.db import models

class Camisa(models.Model):
    CATEGORIAS = [
        ('europeus', 'Europeus'),
        ('selecoes', 'Seleções'),
        ('brasileiros', 'Brasileiros'),
    ]
    nome = models.CharField('Nome da Camisa', max_length=150)
    preco_normal = models.DecimalField('Preço Cartão (6x)', max_digits=8, decimal_places=2)
    preco_pix = models.DecimalField('Preço no PIX', max_digits=8, decimal_places=2)
    imagem = models.ImageField('Foto da Camisa', upload_to='camisas/')
    categoria = models.CharField('Categoria', max_length=20, choices=CATEGORIAS, default='europeus')
    lancamento = models.BooleanField('Mostrar em Lançamentos', default=True)
    mais_vendido = models.BooleanField('Mostrar em Mais Vendidos', default=False)

    def __str__(self):
        return self.nome
