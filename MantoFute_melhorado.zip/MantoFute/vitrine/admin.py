from django.contrib import admin
from .models import Camisa

@admin.register(Camisa)
class CamisaAdmin(admin.ModelAdmin):
    list_display = ('nome', 'categoria', 'preco_pix', 'preco_normal', 'lancamento', 'mais_vendido')
    list_filter = ('categoria', 'lancamento', 'mais_vendido')
    search_fields = ('nome',)
