from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.conf import settings
from .models import Camisa

COMBOS = {3: 379.90, 4: 459.90, 5: 529.90, 6: 635.90, 7: 739.90}

def home(request):
    cat = request.GET.get('categoria')
    if cat:
        camisas_filtradas = Camisa.objects.filter(categoria=cat)
    else:
        camisas_filtradas = None
    lancamentos = Camisa.objects.filter(lancamento=True)[:10]
    mais_vendidos = Camisa.objects.filter(mais_vendido=True)[:10]
    carrinho = request.session.get('carrinho', [])
    return render(request, 'vitrine/home.html', {
        'lancamentos': lancamentos,
        'mais_vendidos': mais_vendidos,
        'camisas_filtradas': camisas_filtradas,
        'categoria_ativa': cat,
        'qtd_carrinho': len(carrinho),
        'whatsapp': settings.WHATSAPP_LOJA,
    })

def detalhe_camisa(request, camisa_id):
    camisa = get_object_or_404(Camisa, id=camisa_id)
    if request.method == 'POST':
        carrinho = request.session.get('carrinho', [])
        carrinho.append({
            'id': camisa.id,
            'nome': camisa.nome,
            'preco_pix': float(camisa.preco_pix),
            'preco_normal': float(camisa.preco_normal),
            'imagem': camisa.imagem.url,
            'tamanho': request.POST.get('tamanho', 'M'),
            'nome_costas': request.POST.get('nome_costas', '').strip().upper(),
            'numero_costas': request.POST.get('numero_costas', '').strip(),
            'patch': request.POST.get('patch') == 'on',
        })
        request.session['carrinho'] = carrinho
        return redirect('ver_carrinho')
    return render(request, 'vitrine/detalhe.html', {
        'camisa': camisa,
        'qtd_carrinho': len(request.session.get('carrinho', [])),
        'whatsapp': settings.WHATSAPP_LOJA,
    })

def ver_carrinho(request):
    carrinho = request.session.get('carrinho', [])
    qtd = len(carrinho)
    total_pix = sum(i['preco_pix'] for i in carrinho)
    total_cartao = sum(i['preco_normal'] for i in carrinho)
    desconto_combo = 0.0
    if qtd in COMBOS:
        total_pix = COMBOS[qtd]
        desconto_combo = max(0.0, total_cartao - total_pix)
    proximo_combo = None
    for k, v in sorted(COMBOS.items()):
        if qtd < k:
            proximo_combo = {'faltam': k - qtd, 'qtd': k, 'valor': f'{v:.2f}'}
            break
    return render(request, 'vitrine/carrinho.html', {
        'carrinho': carrinho,
        'qtd': qtd,
        'qtd_carrinho': qtd,
        'total_pix': f'{total_pix:.2f}',
        'total_cartao': f'{total_cartao:.2f}',
        'desconto_combo': f'{desconto_combo:.2f}',
        'proximo_combo': proximo_combo,
        'whatsapp': settings.WHATSAPP_LOJA,
    })

def remover_item(request, index):
    carrinho = request.session.get('carrinho', [])
    if 0 <= index < len(carrinho):
        carrinho.pop(index)
        request.session['carrinho'] = carrinho
    return redirect('ver_carrinho')

def login_cliente(request):
    erro = None
    if request.method == 'POST':
        email = request.POST.get('email', '').strip()
        senha = request.POST.get('senha', '')
        user = authenticate(request, username=email, password=senha)
        if user:
            login(request, user)
            return redirect('home')
        erro = 'E-mail ou senha inválidos.'
    return render(request, 'vitrine/login.html', {'erro': erro})

def cadastro_cliente(request):
    erro = None
    if request.method == 'POST':
        nome = request.POST.get('nome', '').strip()
        email = request.POST.get('email', '').strip()
        senha = request.POST.get('senha', '')
        if User.objects.filter(username=email).exists():
            erro = 'Este e-mail já está cadastrado.'
        elif nome and email and senha:
            user = User.objects.create_user(username=email, email=email, password=senha, first_name=nome)
            login(request, user)
            return redirect('home')
        else:
            erro = 'Preencha todos os campos.'
    return render(request, 'vitrine/cadastro.html', {'erro': erro})

def logout_cliente(request):
    logout(request)
    return redirect('home')
