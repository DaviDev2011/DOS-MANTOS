from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from vitrine import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),
    path('camisa/<int:camisa_id>/', views.detalhe_camisa, name='detalhe_camisa'),
    path('carrinho/', views.ver_carrinho, name='ver_carrinho'),
    path('carrinho/remover/<int:index>/', views.remover_item, name='remover_item'),
    path('login/', views.login_cliente, name='login_cliente'),
    path('cadastro/', views.cadastro_cliente, name='cadastro_cliente'),
    path('sair/', views.logout_cliente, name='logout_cliente'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
